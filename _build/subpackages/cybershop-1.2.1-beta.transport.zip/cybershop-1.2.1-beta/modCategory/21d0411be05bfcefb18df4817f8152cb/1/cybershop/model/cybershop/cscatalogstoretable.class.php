<?php
class csCatalogStoreTable extends xPDOSimpleObject {}