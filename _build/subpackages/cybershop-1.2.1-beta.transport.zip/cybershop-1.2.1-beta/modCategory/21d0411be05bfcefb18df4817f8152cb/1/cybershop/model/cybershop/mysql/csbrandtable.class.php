<?php
require_once (dirname(dirname(__FILE__)) . '/csbrandtable.class.php');
class csBrandTable_mysql extends csBrandTable {}