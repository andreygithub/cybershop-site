<?php
class csCurrency extends xPDOSimpleObject {}