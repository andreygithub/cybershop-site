<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalogСommenttable.class.php');
class csCatalogСommentTable_mysql extends csCatalogСommentTable {}