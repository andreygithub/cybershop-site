<?php
require_once (dirname(dirname(__FILE__)) . '/cscategory.class.php');
class csCategory_mysql extends csCategory {}