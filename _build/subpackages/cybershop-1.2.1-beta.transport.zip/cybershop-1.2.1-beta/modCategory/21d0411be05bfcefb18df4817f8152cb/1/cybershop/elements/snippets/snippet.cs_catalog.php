<?php
$cs = $modx->getService('cybershop','Cybershop',$modx->getOption('cybershop.core_path',null,$modx->getOption('core_path').'components/cybershop/').'model/cybershop/',$scriptProperties);
if (!($cs instanceof Cybershop)) { die('Error'); }

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&  $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest' && $_REQUEST['action'] == 'filter') {
    
    $cs->initialize($modx->context->key);
    
    $params['tpl_catalog_element'] = $modx->getOption('tpl_catalog_element',$scriptProperties,'cs_tpl_catalog_element');
    $params['tpl_pagination_main'] = $modx->getOption('tpl_pagination_main',$scriptProperties,'cs_tpl_pagination_main');
    $params['tpl_pagination_element'] = $modx->getOption('tpl_pagination_element',$scriptProperties,'cs_tpl_pagination_element');
    
    $params['filter_sort'] = 'name';
    $params['filter_dir'] = 'ASC';
    $params['max_paginetion_elements'] = 10;
    
    $params['categorysgroup']   = isset($_POST['categorysgroup']) ?  $_POST['categorysgroup'] : 0;
    $params['categorys']        = isset($_POST['categorys']) ?  explode(",",$_POST['categorys']) : '';
    $params['brands']           = isset($_POST['brands']) ?  explode(",",$_POST['brands']) : '';
    $params['filters']          = isset($_POST['filters']) ?  explode(",",$_POST['filters']) : '';
    $params['pricemin']         = isset($_POST['pricemin']) ?  $_POST['pricemin'] : 0;
    $params['pricemax']         = isset($_POST['pricemax']) ?  $_POST['pricemax'] : 9999999;
    $params['limit']            = isset($_POST['limit']) ?  $_POST['limit'] : 20;
    $params['offset']           = isset($_POST['page']) ?  $_POST['page'] - 1 : 0;
    $params['sortname']         = isset($_POST['sortname']) ?  $_POST['sortname'] : 'name';
    $params['sortdirection']    = isset($_POST['sortdirection']) ?  $_POST['sortdirection'] : 'ASC';
    $params['options']          = isset($_POST['options']) ?  $_POST['options'] : '';

    $get_pagination = isset($_POST['get_pagination']) ?  $_POST['get_pagination'] : 'true';
    
    $result = $cs->catalog->get_result(@$params);
    $elementArray['rows_result'] = $cs->catalog->phrase_result($result, @$params);

    $pagination = $cs->catalog->get_pagination(@$params);
    
    $data = array();
    
    $data['result'] = $result['rows_result'];
    if ($get_pagination) { $data['pagination'] = $cs->catalog->get_pagination(@$params); }

    $response = array(
            'success' => true
            ,'message' => ''
            ,'data' => $data
    );

    echo json_encode($response);
    exit;
    }
    

$cs->initialize($modx->context->key);
$cs->modx->regClientScript($cs->config['jsUrl'].'web/cybershop.initialize.js');
$cs->modx->regClientScript($cs->config['jsUrl'].'web/cybershop.catalog.js');
$cs->modx->regClientScript($cs->config['jsUrl'].'web/cybershop.hash.js');
$cs->modx->regClientScript
('
<script type="text/javascript">
$(document).ready(function() {
cybershop.catalog.initialize();});
</script>
');
$params = array();

$params['tpl_catalog_main'] = $modx->getOption('tpl_catalog_main',$scriptProperties,'cs_tpl_catalog_main');
$params['tpl_catalog_element'] = $modx->getOption('tpl_catalog_element',$scriptProperties,'cs_tpl_catalog_element');
$params['tpl_pagination_main'] = $modx->getOption('tpl_pagination_main',$scriptProperties,'cs_tpl_pagination_main');
$params['tpl_pagination_element'] = $modx->getOption('tpl_pagination_element',$scriptProperties,'cs_tpl_pagination_element');

$params['max_paginetion_elements'] = 10;

$params['categorysgroup']   = isset($_GET['categorysgroup']) ?  $_GET['categorysgroup'] : 0;
$params['categorys']        = isset($_GET['categorys']) ?  explode(",",$_GET['categorys']) : '';
$params['brands']           = isset($_GET['brands']) ?  explode(",",$_GET['brands']) : '';
$params['filters']          = isset($_GET['filters']) ?  explode(",",$_GET['filters']) : '';
$params['pricemin']         = isset($_GET['pricemin']) ?  $_GET['pricemin'] : 0;
$params['pricemax']         = isset($_GET['pricemax']) ?  $_GET['pricemax'] : 999999999;
$params['limit']            = isset($_GET['limit']) ?  $_GET['limit'] : 20;
$params['offset']           = isset($_GET['page']) ?  $_GET['page'] - 1: 0;
$params['sortname']         = isset($_GET['sortname']) ?  $_GET['sortname'] : 'name';
$params['sortdirection']    = isset($_GET['sortdirection']) ?  $_GET['sortdirection'] : 'ASC';
$params['options']          = isset($_GET['options']) ?  $_GET['options'] : '';
$params['total']            = 0;

$output_block = '';
$output_block_ajax = '';

$result = $cs->catalog->get_result(@$params);
$elementArray['rows_result'] = $cs->catalog->phrase_result($result, @$params);

$category = $modx->getObject('csCategory', $params['categorys'][0]);
$elementArray['category_name'] = $category->get('name');
return $cs->getChunk($params['tpl_catalog_main'],$elementArray);