<?php
class csBrandTable extends xPDOSimpleObject {}