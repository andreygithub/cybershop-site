<?php
require_once (dirname(dirname(__FILE__)) . '/csorderproduct.class.php');
class csOrderProduct_mysql extends csOrderProduct {}