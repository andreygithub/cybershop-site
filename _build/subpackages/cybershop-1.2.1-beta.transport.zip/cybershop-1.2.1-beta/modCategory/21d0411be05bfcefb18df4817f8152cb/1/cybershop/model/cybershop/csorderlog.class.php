<?php
class csOrderLog extends xPDOSimpleObject {}