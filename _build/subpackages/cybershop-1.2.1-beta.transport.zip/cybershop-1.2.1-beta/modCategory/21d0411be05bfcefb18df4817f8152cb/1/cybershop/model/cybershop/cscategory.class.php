<?php
class csCategory extends xPDOSimpleObject {}