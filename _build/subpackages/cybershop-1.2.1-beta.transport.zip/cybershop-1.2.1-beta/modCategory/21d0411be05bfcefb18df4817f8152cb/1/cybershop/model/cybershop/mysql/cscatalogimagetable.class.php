<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalogimagetable.class.php');
class csCatalogImageTable_mysql extends csCatalogImageTable {}