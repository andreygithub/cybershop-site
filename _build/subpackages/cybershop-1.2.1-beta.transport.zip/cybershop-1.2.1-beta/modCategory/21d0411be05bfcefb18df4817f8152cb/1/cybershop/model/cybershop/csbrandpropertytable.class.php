<?php
class csBrandPropertyTable extends xPDOSimpleObject {}