<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'csCatalog',
    1 => 'csCatalogFilterTable',
    2 => 'csCatalogPropertyTable',
    3 => 'csCatalogImageTable',
    4 => 'csCatalogComplectTable',
    5 => 'csCatalogSimilarTable',
    6 => 'csCatalogStoreTable',
    7 => 'csCatalogСommentTable',
    8 => 'csBrand',
    9 => 'csBrandTable',
    10 => 'csBrandPropertyTable',
    11 => 'csCategory',
    12 => 'csCategoryTable',
    13 => 'csCategoryPropertyTable',
    14 => 'csFilter',
    15 => 'csFilterItem',
    16 => 'csProperty',
    17 => 'csStore',
    18 => 'csDelivery',
    19 => 'csPayment',
    20 => 'csCurrency',
    21 => 'csOrder',
    22 => 'csOrderStatus',
    23 => 'csOrderLog',
    24 => 'csOrderAddress',
    25 => 'csOrderProduct',
  ),
);