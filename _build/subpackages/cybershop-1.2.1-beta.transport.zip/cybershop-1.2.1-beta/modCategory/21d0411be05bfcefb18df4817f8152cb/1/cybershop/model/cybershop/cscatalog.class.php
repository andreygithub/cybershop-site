<?php
class csCatalog extends xPDOSimpleObject {}