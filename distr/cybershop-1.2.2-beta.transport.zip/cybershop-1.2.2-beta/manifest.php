<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog file for Cybershop component.

Cybershop 1.2.1 beta
====================================
- Updates and remove some bugs

Cybershop 1.1 beta
====================================
- Updates 

Cybershop 1.0 beta
====================================
- Updates',
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
Extra: Cybershop
--------------------
Version: 1.1 beta
Since: September 2013
Author: Andrey Zagorets <AndreyZagorets@gmail.com>

Простой и удобный интернет магазин
',
    'setup-options' => 'cybershop-1.2.2-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b224b7d02d063ce731b6f33a49d03b76',
      'native_key' => 'cybershop',
      'filename' => 'modNamespace/fa2c9f40d0520c6894fac66d258de4e8.vehicle',
      'namespace' => 'cybershop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ee051db6e7b14568bec1e4af6f74148',
      'native_key' => 'cybershop.email_manager',
      'filename' => 'modSystemSetting/d9d6101125c1d2c22dc2b8228ace7775.vehicle',
      'namespace' => 'cybershop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4828a6285cc1c44a8d59bf517c3e151f',
      'native_key' => 'cybershop.order_user_groups',
      'filename' => 'modSystemSetting/c1fab64cadbe61af1dff0b195c618b55.vehicle',
      'namespace' => 'cybershop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fc62164e46c1da97551af1decd012f5',
      'native_key' => 'cybershop.catalog_image_path',
      'filename' => 'modSystemSetting/a79140d49ee70a959ea8554209e9973b.vehicle',
      'namespace' => 'cybershop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8116b79b6ffdb21128eb0530dcfd2a31',
      'native_key' => 'cybershop.catalog_media_path',
      'filename' => 'modSystemSetting/a6d9439123489c4b4c9a1ce7f6cbc5c6.vehicle',
      'namespace' => 'cybershop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63724ce4e18d00e317bea9311f2d3e9e',
      'native_key' => 'cybershop.catalog_import_path',
      'filename' => 'modSystemSetting/d6795cfede67708f81763f4ddfe84468.vehicle',
      'namespace' => 'cybershop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f2bdc3486a37793f4b10d852398987b',
      'native_key' => 'cybershop.import_delimiter',
      'filename' => 'modSystemSetting/8d2e30371850d01c7959de5ba2049929.vehicle',
      'namespace' => 'cybershop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71ebc34baaa0510a25426fd437bfcf4a',
      'native_key' => 'cybershop.catalog_categorysgroup',
      'filename' => 'modSystemSetting/4dc96f9eb0c1f1035aa94acc981aeca4.vehicle',
      'namespace' => 'cybershop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bbb853d6e3e9106ad99341ddb098fee',
      'native_key' => 'cybershop.catalog_categorys',
      'filename' => 'modSystemSetting/dd50177cb0850103b38135c209606d73.vehicle',
      'namespace' => 'cybershop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad82a5186c0bca704219206557f80f88',
      'native_key' => 'cybershop.catalog_brands',
      'filename' => 'modSystemSetting/7dff46370a413d840d13374a020f8956.vehicle',
      'namespace' => 'cybershop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c189457b1c99cc02198956cdf59ac59',
      'native_key' => 'cybershop.catalog_filters',
      'filename' => 'modSystemSetting/df55c7f6bf98e7c8f1475636815aaed1.vehicle',
      'namespace' => 'cybershop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbc7b98f4c7a23566adc9d61417dfcc2',
      'native_key' => 'cybershop.catalog_pricemin',
      'filename' => 'modSystemSetting/7c9a1f2fc1cfaaa51b09039ea701c7d0.vehicle',
      'namespace' => 'cybershop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16dbcfcf266f35d205c3bc0348dbdc17',
      'native_key' => 'cybershop.catalog_pricemax',
      'filename' => 'modSystemSetting/15226f13a6fdb40cfbad7eff88bee583.vehicle',
      'namespace' => 'cybershop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f201d06b4a95035cd4777ba9756bfabe',
      'native_key' => 'cybershop.catalog_limit',
      'filename' => 'modSystemSetting/c0607c0f77576b65218bbbdae671eb7b.vehicle',
      'namespace' => 'cybershop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c104dc5f36fe6b0c40ec0804c16c4e6e',
      'native_key' => 'cybershop.catalog_sortname',
      'filename' => 'modSystemSetting/f6e2b8fb768056d6098dabd22596425f.vehicle',
      'namespace' => 'cybershop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7638c66a2b389d5968240697c98cb440',
      'native_key' => 'cybershop.catalog_sortdirection',
      'filename' => 'modSystemSetting/baacb4823740ed5d68b1952e93e20ae8.vehicle',
      'namespace' => 'cybershop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b52ed8300819e98c1632fff8a7a9a9d',
      'native_key' => 'cybershop.catalog_index_fields',
      'filename' => 'modSystemSetting/bac1e3a3dcfd1f05150e79911d1d09ab.vehicle',
      'namespace' => 'cybershop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e059a6a5e0730f5c28ff694792a8a9a4',
      'native_key' => 'cybershop.currency',
      'filename' => 'modSystemSetting/024a7edb595f50f7ad4149a8f2d004e3.vehicle',
      'namespace' => 'cybershop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c16300a152a3160294ec517e22f6c7c',
      'native_key' => 'cybershop.price_format',
      'filename' => 'modSystemSetting/0603699b6e17eb6a42bac17fca6e7907.vehicle',
      'namespace' => 'cybershop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14d47eee83c9a016cb1a42ec0ac3150b',
      'native_key' => 'cybershop.price_format_no_zeros',
      'filename' => 'modSystemSetting/85d0efb10045503d398ea8b3abc509ce.vehicle',
      'namespace' => 'cybershop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f32d2e64b56637a871eeaf0a5c2c1e4',
      'native_key' => 'cybershop.weight_format',
      'filename' => 'modSystemSetting/95ddbf2dd2f0af6e0e02ad2be7eabfb1.vehicle',
      'namespace' => 'cybershop',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b906ad80f639712b6c10a7724a41df63',
      'native_key' => 'cybershop.weight_format_no_zeros',
      'filename' => 'modSystemSetting/7c295dfb6590e53b9abc40639f2b91d1.vehicle',
      'namespace' => 'cybershop',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fda222c92af32396e2c2b68297d5076',
      'native_key' => 'cybershop.res_catalog_element_id',
      'filename' => 'modSystemSetting/97499d7037e0c6db095bbebc33a1d09b.vehicle',
      'namespace' => 'cybershop',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '869d36d0e0db057f029af0d95a7b416c',
      'native_key' => 'cybershop.res_catalog_get_id',
      'filename' => 'modSystemSetting/a5472d738d9e1c717a2757e97d7cc649.vehicle',
      'namespace' => 'cybershop',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17fd44302e010001eddec473834be20d',
      'native_key' => 'cybershop.res_catalog_id',
      'filename' => 'modSystemSetting/3d37f5f78d6341741d43d0b6ad2b3e81.vehicle',
      'namespace' => 'cybershop',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de1fcc3344a3ee0671f8c868a7a27c01',
      'native_key' => 'cybershop.res_cart_id',
      'filename' => 'modSystemSetting/d71e6c47d3ff793d523c07f5bfd5ed49.vehicle',
      'namespace' => 'cybershop',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04b52e09e752ae17f20a9cdc3b6487bb',
      'native_key' => 'cybershop.res_cart_order_id',
      'filename' => 'modSystemSetting/e7572a38cf39d8acad6eff8acf5b6231.vehicle',
      'namespace' => 'cybershop',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98f1554ece07a4121e3277fa19514f15',
      'native_key' => 'cybershop.res_cart_order_result_id',
      'filename' => 'modSystemSetting/29d5889b2520b44d27a9d78d632bc207.vehicle',
      'namespace' => 'cybershop',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9859c9edc7693c6000ffbd4325f990e8',
      'native_key' => 'csOnBeforeAddToCart',
      'filename' => 'modEvent/7454eaa91f6a987d460d76e08458c095.vehicle',
      'namespace' => 'cybershop',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '115f7e5482af29a29a40ab51e4509b88',
      'native_key' => 'csOnAddToCart',
      'filename' => 'modEvent/3795fe2e8da858a3af9c80970bb85d75.vehicle',
      'namespace' => 'cybershop',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dee7e2165556cdbdf749d75d6ee5ba1b',
      'native_key' => 'csOnBeforeChangeInCart',
      'filename' => 'modEvent/ec0bc46fb8e9f0b2f2082ea71fc976ff.vehicle',
      'namespace' => 'cybershop',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '981836514332005e89d72a3b1b72a7f1',
      'native_key' => 'csOnChangeInCart',
      'filename' => 'modEvent/2d4fd3548d011f810b5013c4963404a2.vehicle',
      'namespace' => 'cybershop',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00f574f94ce7d21b476ef656c6d5d79b',
      'native_key' => 'csOnBeforeRemoveFromCart',
      'filename' => 'modEvent/d5b9ce6074e24b39bad538cd6d03d3d3.vehicle',
      'namespace' => 'cybershop',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b228cc5548a7d0aa66d17c4fc7f93068',
      'native_key' => 'csOnRemoveFromCart',
      'filename' => 'modEvent/fc2321be39c3687d893b42e8311c8116.vehicle',
      'namespace' => 'cybershop',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06338939406f579e3c116b21e7139d6a',
      'native_key' => 'csOnBeforeEmptyCart',
      'filename' => 'modEvent/dcf931c0b7ffabf913c081450bf4ddbb.vehicle',
      'namespace' => 'cybershop',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7f890ff1af61f640856c13220c386a6',
      'native_key' => 'csOnEmptyCart',
      'filename' => 'modEvent/a96ba377ab1189874ce77283796e100b.vehicle',
      'namespace' => 'cybershop',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76a4c21fb04540c73dc88fd650bfba11',
      'native_key' => 'csOnBeforeAddToOrder',
      'filename' => 'modEvent/93c04c979009182be10937daeed669c8.vehicle',
      'namespace' => 'cybershop',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a21a228a9930edd5afa90573e95b5eb',
      'native_key' => 'csOnAddToOrder',
      'filename' => 'modEvent/d29ba37f2a6a8dd3d584acf5e1bc5e6f.vehicle',
      'namespace' => 'cybershop',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c819be74d7002efebe28f09a2e9b1ae',
      'native_key' => 'csOnBeforeRemoveFromOrder',
      'filename' => 'modEvent/b70b854e7d29dab86cca1c1b90504f56.vehicle',
      'namespace' => 'cybershop',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68cf4f52d8a2fd561afb0290afe2511a',
      'native_key' => 'csOnRemoveFromOrder',
      'filename' => 'modEvent/90547a720b21ca1ed6223e990d7c766b.vehicle',
      'namespace' => 'cybershop',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7939da3cbc5daeeb4c27cde01ba1fcd',
      'native_key' => 'csOnBeforeEmptyOrder',
      'filename' => 'modEvent/10d81747512d67f4321761e00cae338e.vehicle',
      'namespace' => 'cybershop',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11d46fb8546980b2c867b959c80a56c2',
      'native_key' => 'csOnEmptyOrder',
      'filename' => 'modEvent/bbeed3bdedc4e2e17372559cef8e52e5.vehicle',
      'namespace' => 'cybershop',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65c90a80da475525abced2f33413fe92',
      'native_key' => 'csOnBeforeChangeOrderStatus',
      'filename' => 'modEvent/8c1931e41c74e73722b0e1088af88ac3.vehicle',
      'namespace' => 'cybershop',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ecfe04209e652dc3484448bdaaed3cb',
      'native_key' => 'csOnChangeOrderStatus',
      'filename' => 'modEvent/e432753ea797bc9db3be4c2f1a4f0c16.vehicle',
      'namespace' => 'cybershop',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37437f44798f8006e69cf35bc5bc6c39',
      'native_key' => 'csOnBeforeUpdateOrder',
      'filename' => 'modEvent/dffa95bb4acde496f8dd1c76e404daa7.vehicle',
      'namespace' => 'cybershop',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09d3bb46c4c5055bfa8fc07b32680793',
      'native_key' => 'csOnUpdateOrder',
      'filename' => 'modEvent/9617a1370718540f50b3b3a2355ab969.vehicle',
      'namespace' => 'cybershop',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ecfb0be9b19caa62560494d04c06f1c',
      'native_key' => 'csOnBeforeCreateOrder',
      'filename' => 'modEvent/4448c33a308db4175de7fc2811eeec21.vehicle',
      'namespace' => 'cybershop',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e71d46c3f92a78563d6d2c5aed580d03',
      'native_key' => 'csOnCreateOrder',
      'filename' => 'modEvent/6296cd0a675041a159c121abe5ee55a3.vehicle',
      'namespace' => 'cybershop',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b13df44fb8a97e74148201b18fbd510',
      'native_key' => 'csOnSubmitOrder',
      'filename' => 'modEvent/ec3f6a6f98d99de92c97d4acebe82b71.vehicle',
      'namespace' => 'cybershop',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22e94e5bd4a0266de25d4c12ffe6b3e7',
      'native_key' => 'csOnManagerCustomCssJs',
      'filename' => 'modEvent/49b5de71101f0ec7feb6ab22aa2d187c.vehicle',
      'namespace' => 'cybershop',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a08c0a981cc2bb2a3786ffab7f8bda98',
      'native_key' => 0,
      'filename' => 'modAccessPolicy/9f4c4d85e2d608149e05eb03d36832d6.vehicle',
      'namespace' => 'cybershop',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '279e04142eb63dee713f971ae80c8280',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/60e882912395ed1c85950a9e4f0f24fb.vehicle',
      'namespace' => 'cybershop',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'a233c4f32314ef58c55bfb99a1252f59',
      'native_key' => 0,
      'filename' => 'modUserGroup/7913d28277016df0d4c125fd6cb3f86b.vehicle',
      'namespace' => 'cybershop',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bbc57e116c6da349022889c33768f97d',
      'native_key' => 'cybershop',
      'filename' => 'modMenu/69ab5186e03d51f6cda679ba56c093e5.vehicle',
      'namespace' => 'cybershop',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2142a0cb1bb78ba1e2e01f35baeddaae',
      'native_key' => 'cs_orders',
      'filename' => 'modMenu/3c4d9b84a467a8a3cc7992686cd198f9.vehicle',
      'namespace' => 'cybershop',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '44e0dffaffbef20ed61eb2b99b7af49d',
      'native_key' => 'cs_catalog',
      'filename' => 'modMenu/4084ac7b7b380e120c6333a074d0faa5.vehicle',
      'namespace' => 'cybershop',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '01b9b53d0d6fd25239d37dbf685118ac',
      'native_key' => 'cs_settings',
      'filename' => 'modMenu/db7c70c1efc0dc05860b53afce2dba16.vehicle',
      'namespace' => 'cybershop',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3bf4be525941f824dc76935ca3ecbb46',
      'native_key' => 'cs_categorys',
      'filename' => 'modMenu/09530ff1f5051fcc267c5f3d568d281e.vehicle',
      'namespace' => 'cybershop',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '70238c26d8054b9ba30a6134b9859096',
      'native_key' => 'cs_brands',
      'filename' => 'modMenu/2a1095ec9102bca641fb30b55da42eb8.vehicle',
      'namespace' => 'cybershop',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b9f514e6fd7841c8edd46a8db64789e6',
      'native_key' => 'cs_filters',
      'filename' => 'modMenu/2b22124f87dfb8e7b5fa285998f11496.vehicle',
      'namespace' => 'cybershop',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8750c0f4f4073590bdbe6208e7f32947',
      'native_key' => 'cs_properties',
      'filename' => 'modMenu/23687de0b959c7db0364fe28edf9266f.vehicle',
      'namespace' => 'cybershop',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'df0bef1ed444eb10cd78abc6cc8c6cd3',
      'native_key' => 'cs_payment',
      'filename' => 'modMenu/b31351c319d0a88a5861a0d872171d50.vehicle',
      'namespace' => 'cybershop',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '60b46f2ee7f96545a9fa55e30396ccf4',
      'native_key' => 'cs_status',
      'filename' => 'modMenu/2d9a3b583c121c51e5d096a8cae44d50.vehicle',
      'namespace' => 'cybershop',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bcdb856a24310006bd3f774bd0efc1f9',
      'native_key' => 'cs_delivery',
      'filename' => 'modMenu/dec916ef9d5e9528f6bed62aad597df1.vehicle',
      'namespace' => 'cybershop',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f17d11a07446bfb52aab5bd62f3d1c86',
      'native_key' => 'cs_currency',
      'filename' => 'modMenu/ae3c2003ac094407c7c0ae6a93bd1709.vehicle',
      'namespace' => 'cybershop',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e7e37e953b085e7109d16ce0c48c6913',
      'native_key' => 1,
      'filename' => 'modCategory/298993e770e19db621f07c8e49baa172.vehicle',
      'namespace' => 'cybershop',
    ),
  ),
);