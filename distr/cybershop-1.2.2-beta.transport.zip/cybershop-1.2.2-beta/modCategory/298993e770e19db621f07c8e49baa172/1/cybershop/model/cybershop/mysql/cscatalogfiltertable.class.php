<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalogfiltertable.class.php');
class csCatalogFilterTable_mysql extends csCatalogFilterTable {}