<?php
class csCatalogFilterTable extends xPDOSimpleObject {}