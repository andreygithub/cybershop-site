<?php
class csCatalogIndexWords extends xPDOSimpleObject {}