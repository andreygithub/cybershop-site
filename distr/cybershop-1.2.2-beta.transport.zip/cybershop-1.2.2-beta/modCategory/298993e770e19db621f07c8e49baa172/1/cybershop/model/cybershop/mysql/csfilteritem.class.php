<?php
require_once (dirname(dirname(__FILE__)) . '/csfilteritem.class.php');
class csFilterItem_mysql extends csFilterItem {}