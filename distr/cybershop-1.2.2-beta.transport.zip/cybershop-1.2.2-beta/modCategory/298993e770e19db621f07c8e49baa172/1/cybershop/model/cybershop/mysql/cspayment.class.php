<?php
require_once (dirname(dirname(__FILE__)) . '/cspayment.class.php');
class csPayment_mysql extends csPayment {}