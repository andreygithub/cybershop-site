<?php
require_once (dirname(dirname(__FILE__)) . '/cscategorypropertytable.class.php');
class csCategoryPropertyTable_mysql extends csCategoryPropertyTable {}