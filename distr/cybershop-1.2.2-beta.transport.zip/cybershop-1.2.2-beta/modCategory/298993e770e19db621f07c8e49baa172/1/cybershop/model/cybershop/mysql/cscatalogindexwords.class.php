<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalogindexwords.class.php');
class csCatalogIndexWords_mysql extends csCatalogIndexWords {}