<?php
class csCategoryTable extends xPDOSimpleObject {}