<?php
require_once (dirname(dirname(__FILE__)) . '/csstore.class.php');
class csStore_mysql extends csStore {}