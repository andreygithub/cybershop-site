<?php
class csCatalogSimilarTable extends xPDOSimpleObject {}