<?php
require_once (dirname(dirname(__FILE__)) . '/csfilter.class.php');
class csFilter_mysql extends csFilter {}