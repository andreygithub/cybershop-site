<?php
class csOrderStatus extends xPDOSimpleObject {}