<?php
$cs = $modx->getService('cybershop','Cybershop',$modx->getOption('cybershop.core_path',null,$modx->getOption('core_path').'components/cybershop/').'model/cybershop/',$scriptProperties);
if (!($cs instanceof Cybershop)) { return; }

$tpl_main = $modx->getOption('tpl_main',$scriptProperties,'cs_tpl_category_main');
$tpl_element = $modx->getOption('tpl_element',$scriptProperties,'cs_tpl_category_element');
$tpl_element_active = $modx->getOption('tpl_element_active',$scriptProperties,$tpl_element);
$parent = $modx->getOption('parent',$scriptProperties,0);
$catalog_get_id = $modx->getOption('catalog_get_id',$scriptProperties,$modx->getOption('cybershop.res_catalog_get_id'));
$sort = $modx->getOption('sort',$scriptProperties,'id');
$dir = $modx->getOption('dir',$scriptProperties,'ASC');

$params['categorys']        = isset($_GET['categorys']) ?  explode(",",$_GET['categorys']) : '';

$c = $modx->newQuery('csCategory');
$c->where(array(
    'parent' => $parent,
));
$c->sortby($sort,$dir);
$elements = $modx->getCollection('csCategory',$c);

$output = '';
$output_rows = '';

foreach ($elements as $element) {
    $elementArray = $element->toArray();
    if ($elementArray['isfolder']) {
        $link = $modx->makeUrl($catalog_get_id)."?categorysgroup={$elementArray['id']}";
    } else {
        $link = $modx->makeUrl($catalog_get_id)."?categorysgroup=0&categorys={$elementArray['id']}";
    }
    $elementArray['link'] = $link;
    if (in_array($elementArray['id'], $params['categorys'])) {
        $output_rows .= $cs->getChunk($tpl_element_active, $elementArray);
    } else {
        $output_rows .= $cs->getChunk($tpl_element,$elementArray);
    }
}

$elementArray = array(
    'rows' => $output_rows
);

return $cs->getChunk($tpl_main,$elementArray);